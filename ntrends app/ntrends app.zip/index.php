<?php
// This file sits in the root folder.
// Its only job is to redirect users to the login page immediately.

header("Location: login.php");
exit;
?>